Beta 1.0b

!!! Many many "ditches"

(1) The Main Program

Tutorial: How To Make A Playlist For The Pack

-> Run The croamp.exe
-> Right Mouse Button on The Playlist Box
-> Select: Add Dir
-> Select The Folder Where CroAmp.exe is (ex. c:\croamp)
-> Wait The End Of The Search
-> Edit All The Entry As You Want! (Select The Entry And Then Ctrl+E)
-> Right Mouse Button on The Playlist Box
-> Select: Save As...
-> Save The Playlist As croamp.pl Into The Folder Where CroAmp.exe is (ex. c:\croamp)

Now Every Time That You Run Croamp.exe it loads croamp.pl

(2) The Musicians Of The Cro List And Their Emails

Plz Edit This File Adding All The Cro Membs And Their Emails and then send to me!
This File Is Used by CroAmp.exe when u edit an entry, it is needed 2 speed up the editing!

How to add entry in artists.pl?
simple, open artists.pl in notepad and edit aS:

name,email

Ex. 
neo,neo@creation.org



For Explaination write to >> info@creaction.org


DaGOD & Fussie