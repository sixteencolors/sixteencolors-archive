ASCII art viewing 101.

Okay.  I've had it up to ^^ here with people incorrectly viewing the 
Mimic packs.  Here's how it works, folks.  Unless otherwise stated, 
standard ascii is viewed in a 640x400 fullscreen console (a la DOS).  
640x400 translates to 80 characters width at 8 pixels each and 
25 characters length at 16 pixels each.  (80x25).

Programs such as Pablodraw, NFO file viewers and (god forbid) notepad 
will *not* view art in this pack correctly.  Without the proper 
dimensions the asciis will not appear as the artist intended.

HOWEVER, there are certain variations to the rules that you must be 
aware of.  Some 'oldschool' asciis will specify that you view them in a 
different format.  Sometimes the format will be 80x50 (which almost all 
console editors/viewers support), but more importantly some might 
suggest you use "afs.com" or the "amiga font".  This requires a 
different fontset than the standard IBM-PC font so having it [the font] 
available on your harddrive is always a good idea.

Included in this pack are the pc and amiga fontsets.  A lot of dos 
prompts in newer versions of Windows don't apply the proper IBM-PC 
fonts, so running pc.com and comparing it with what you have by default 
is a good idea.

The included files are:
                        pc.com   &
                        amiga.com

Run these in your typical dos prompt and it'll change your font 
accordingly.

As for ansi/ascii editors, here is a list of ones that Mimic artists 
themselves use.

ACiDDraw 1.25 Registered
ftp://ftp.artpacks.acid.org/pub/artpacks/programs/dos/editors/adraw125.zip
------------------------
Empathy 0.79c
ftp://ftp.artpacks.acid.org/pub/artpacks/programs/dos/editors/emp079c.zip
------------------------

ansi/ascii viewers can be found here:

ACiD View v4.36 Multiformat Image Viewer
ftp://ftp.artpacks.acid.org/pub/artpacks/programs/dos/viewers/avd-436.zip
------------------------
Iceview v0.66
ftp://ftp.artpacks.acid.org/pub/artpacks/programs/dos/viewers/icev066.zip
------------------------
Avenge View v2.05e - ANSI/BIN Image Viewer
ftp://ftp.artpacks.acid.org/pub/artpacks/programs/dos/viewers/ave205e.zip
------------------------
