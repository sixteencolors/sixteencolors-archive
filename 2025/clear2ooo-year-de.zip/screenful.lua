afile = "/tmp/noybsttynoybtermnoybsize"
comd = "stty size > " .. afile
h = os.execute(comd)
fi = io.open(afile, "r")
a = fi:read()
fi:close()
u = string.find(a, " ", 1, true)
if u then
	numrows = string.sub(a, 1, u - 1) + 0
	numcols = string.sub(a, u + 1) + 0
end

afile = arg[1]
fi = io.open(afile, "r")
if fi then
	u = 1
	for a in fi:lines() do
		print(a)
		u = u + 1
		if u >= numrows then
			u = 1
			h, he = os.execute("sleep 1")
            if h == nil and he == "signal" then break end
		end
	end
	fi:close()
else
    print("After script name, please enter full path of existing text file.")
end
