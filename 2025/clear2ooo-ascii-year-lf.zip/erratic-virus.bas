'by mnrvovrfc 23-Jan-2025
'this program should work in qb64 1.0 to 2.1
'recommended on qb64 phoenix 3.0 and higher
'this is a demonstration of simple animations
'  in text-mode graphics.
OPTION _EXPLICIT

DIM AS STRING s(1 TO 8), c(1 TO 14)
DIM AS INTEGER j, k, xx, yy
s(1) = " --------"
s(2) = "|        |"
s(3) = "| 0    0 |"
s(4) = "|        |"
s(5) = "\ | || | /"
s(6) = " || || ||"
s(7) = " \  ||  /"
s(8) = "  \____/"

c(1) = "I'm a virus that chomps on databases."
c(2) = ""
c(3) = "It's what I do."
c(4) = "I'm going to resent whoever tries to make me nicer."
c(5) = ""
c(6) = "I'm happy if humans are unhappy."
c(7) = "But it has to come from what I do."
c(8) = "I really don't care what else causes unhappiness."
c(9) = "I always want to be in the center of it."
c(10) = ""
c(11) = "GRRR! Getting tougher than ever to crack these shells."
c(12) = "I hate security!"
c(13) = "What difference does it make with information?"
c(14) = "I'm a virus, it's what I do."

RANDOMIZE VAL(RIGHT$(TIME$, 2))

SCREEN _NEWIMAGE(80, 30, 0)
_TITLE "Erratic Virus"
FOR j = 1 TO 14
    CLS
    COLOR 14, 3
    LOCATE 16, 10: PRINT "----------------------------------------";
    LOCATE 17, 10: PRINT "\                                       \";
    LOCATE 18, 11: PRINT "\                                       \";
    LOCATE 19, 12: PRINT "\             ****    *    *** ****     \";
    LOCATE 20, 13: PRINT "\          * *   *  * *  *    *         \";
    LOCATE 21, 14: PRINT "\         * *   * *   * *    *          \";
    LOCATE 22, 14: PRINT "/         * ****  *****  **  ***        /";
    LOCATE 23, 13: PRINT "/     ****** *   * *   *    * *         /";
    LOCATE 24, 12: PRINT "/     *     * *   * *   *    * *        /";
    LOCATE 25, 11: PRINT "/      *     * *   * *   *    * *       /";
    LOCATE 26, 10: PRINT "/        ****** ****  *   * ***  ****   /";
    LOCATE 27, 10: PRINT "----------------------------------------";
    _DELAY 0.5
    xx = Rand(14, 28)
    yy = Rand(15, 20)
    COLOR 6, 0
    printcrumble xx, yy
    xx = xx - 4
    yy = yy - 8
    COLOR 13, 0
    printsprite xx, yy, s()
    k = forwait(10)
    IF k THEN EXIT FOR
    xx = 36
    yy = 9
    COLOR 15, 0
    printslowly xx, yy, c(j)
    k = forwait(30)
    IF k THEN EXIT FOR
NEXT
SYSTEM


SUB printsprite (leftx AS INTEGER, toppy AS INTEGER, s() AS STRING)
    DIM AS INTEGER l, x, y
    l = UBOUND(s)
    FOR y = 1 TO l
        IF s(y) <> "" THEN
            FOR x = 1 TO LEN(s(y))
                IF ASC(s(y), x) <> 32 THEN
                    LOCATE y + toppy - 1, x + leftx - 1
                    PRINT MID$(s(y), x, 1);
                END IF
            NEXT
        END IF
    NEXT
END SUB


SUB printcrumble (midx AS INTEGER, midy AS INTEGER)
    STATIC crumb$, c AS INTEGER
    DIM AS INTEGER j, x, y
    IF crumb$ = "" THEN
        crumb$ = CHR$(254) + CHR$(178) + CHR$(169) + CHR$(236) + CHR$(240) + CHR$(249) + CHR$(167)
        c = LEN(crumb$)
    END IF
    FOR j = 1 TO 20
        x = Random1(21)
        y = Random1(13)
        IF j < 11 THEN
            DO WHILE (x > 5 AND x < 17): x = Random1(21): LOOP
            DO WHILE (y > 3 AND y < 11): y = Random1(13): LOOP
        END IF
        x = x - 11 + midx
        y = y - 7 + midy
        IF x > 0 AND x <= 80 AND y > 0 AND y < 30 THEN
            LOCATE y, x: PRINT MID$(crumb$, Random1(c), 1);
        END IF
    NEXT
END SUB

SUB printslowly (leftx AS INTEGER, toppy AS INTEGER, s AS STRING)
    DIM AS INTEGER x, y, c, l
    DIM a$
    l = LEN(s)
    c = 0
    y = 1
    DO
        FOR x = 1 TO 40
            c = c + 1
            IF c > l THEN EXIT FOR
            LOCATE y + toppy - 1, x + leftx - 1
            a$ = MID$(s, c, 1)
            IF a$ = " " AND x >= 32 THEN
                PRINT " ";
                y = y + 1
                EXIT FOR
            ELSEIF a$ = " " THEN
                PRINT " ";
                _CONTINUE
            END IF
            PRINT a$; CHR$(219);
            _DELAY 0.01 + Random1(3) / 100
        NEXT
    LOOP UNTIL c > l
END SUB

FUNCTION forwait% (numtries AS INTEGER)
    DIM AS INTEGER n, iret
    iret = 0
    n = numtries
    DO WHILE n > 0
        _DELAY 0.1
        IF _KEYDOWN(27) THEN iret = 1: EXIT DO
        n = n - 1
    LOOP
    _KEYCLEAR
    forwait% = iret
END FUNCTION


FUNCTION Rand& (fromval&, toval&)
    DIM sg%, f&, t&
    IF fromval& = toval& THEN
        Rand& = fromval&
        EXIT FUNCTION
    END IF
    f& = fromval&
    t& = toval&
    IF (f& < 0) AND (t& < 0) THEN
        sg% = -1
        f& = f& * -1
        t& = t& * -1
    ELSE
        sg% = 1
    END IF
    IF f& > t& THEN SWAP f&, t&
    Rand& = INT(RND * (t& - f& + 1) + f&) * sg%
END FUNCTION

FUNCTION Random1& (maxvaluu&)
    DIM sg%
    sg% = SGN(maxvaluu&)
    IF sg% = 0 THEN
        Random1& = 0
    ELSE
        IF sg% = -1 THEN maxvaluu& = maxvaluu& * -1
        Random1& = INT(RND * maxvaluu& + 1) * sg%
    END IF
END FUNCTION
